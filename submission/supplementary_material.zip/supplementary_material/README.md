# Supplementary material (anonymous)

* `supplement.pdf` -- the supplementary document referenced by the paper.
* `code/experiments/` -- the prompts (`prompts.py`; the SciBench variants are
  produced by `_xdom_prompt_patch.py`), the JSON schemas of the enforced condition
  (`schemas.py`), the runners (`runner.py` for Omni-MATH, `runner_xdomain.py` for
  SciBench), the batch driver (`run_bf.sh`) and its helpers, and the offline tests
  (`test_bf_delivery.py`, `test_afs.py`; zero API calls).
* `code/analysis/scripts/` -- every script that produces a number, table or figure:
  `FINAL_TABLES.py` (frozen snapshot), `INDEPENDENT_AUDIT.py` (an independent
  re-implementation), `bf_numbers.py` (the feedback-matched condition),
  `bf_gate.py` (submission gate, verdict-matched recovery, the forced-submission
  run), `mk_*.py` (tables and Figure 1).
* `code/analysis/out/` -- the canonical outputs those scripts write; every number
  in the paper and in `supplement.pdf` can be found in them.
* `code/experiments/results/**/MANIFEST*.json` -- sha256 manifests of the frozen
  snapshot and of the feedback-matched runs.

For anonymity, the inference endpoint URL, the name of the authentication helper,
local file paths and organisation/dataset names have been replaced by placeholders
(`INFERENCE-ENDPOINT`, `auth_token_helper`, `LOCAL-PATH`, `ANON-*`, `PRIOR-CORPUS*`).
The raw trajectories (about 300 MB of JSONL) are not included; they will be
released with the camera-ready version. The scripts read them from the paths
recorded in the manifests.
