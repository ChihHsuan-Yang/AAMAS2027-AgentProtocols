# Supplementary material (anonymous)

* `supplement.pdf` -- the supplementary document referenced by the paper.
* `code/experiments/` -- the prompts (`prompts.py`; the SciBench variants are
  produced by `_xdom_prompt_patch.py`), the JSON schemas of the enforced condition
  (`schemas.py`), the runners (`runner.py` for Omni-MATH, `runner_xdomain.py` for
  SciBench), the batch driver (`run_bf.sh`) and its helpers, and the offline tests
  (`test_bf_delivery.py`, `test_afs.py`; zero API calls).
* `code/analysis/scripts/` -- every script that produces a number, table or figure:
  `FINAL_TABLES.py` (frozen snapshot), `INDEPENDENT_AUDIT.py` (an independent
  re-implementation), `bf_numbers.py` (the feedback-matched condition),
  `bf_gate.py` (submission gate, verdict-matched recovery, the forced-submission
  run), `mk_*.py` (tables, the main paper's Figures 1 and 2, and the four supplement figures).
* `code/analysis/out/` -- the canonical outputs those scripts write; every number
  in the paper and in `supplement.pdf` can be found in them.
* `code/experiments/results/**/MANIFEST*.json` -- sha256 manifests of the frozen
  snapshot and of the feedback-matched runs.
* `code/paper/tables/` -- the generated LaTeX of every table in the paper and in
  `supplement.pdf`, each with its provenance header.

Requirements: Python 3 with numpy, pandas and pyarrow (analysis), matplotlib and
fontTools (figures), and httpx (runners). The figure scripts and the JSON-driven
table scripts (`mk_table_main.py`, `mk_gate_table.py`, `mk_robust_table.py`,
`mk_afs_table.py`, `mk_bf_replication.py`) need only `code/analysis/out/` and
`code/paper/tables/`; `FINAL_TABLES.py`, `INDEPENDENT_AUDIT.py`, `bf_numbers.py`,
`bf_gate.py`, `xdom_analyze.py`, `stat_audit_a7_power.py` and the full run of
`mk_tables.py` also read the raw trajectories. The runners call an
OpenAI-compatible vLLM server; its address and the token helper are site-specific
and are not included.

For anonymity, the inference endpoint URL, the name of the authentication helper,
local file paths and organisation/dataset names have been replaced by placeholders
(`INFERENCE-ENDPOINT`, `auth_token_helper`, `LOCAL-PATH`, `ANON-*`, `PRIOR-CORPUS*`).
The raw trajectories (about 300 MB of JSONL) are not included; they will be
released with the camera-ready version. The scripts read them from the paths
recorded in the manifests.
